public class User {
	private String userName;
	private Role userRole;
	
	User(String userName,Role userRole){
		this.userName=userName;
		this.userRole= userRole;
	}
	
	public String getUserName() {
		return userName;
	}
	
	
	
	
	


}
